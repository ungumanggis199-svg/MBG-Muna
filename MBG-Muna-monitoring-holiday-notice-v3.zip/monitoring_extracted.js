

    // MONITORING_OPERATIONAL_DAYS_FIX_V2: rekap hanya hari Senin-Jumat dan bukan libur nasional.
    let monitoringData = [];
    let allSppgList = [];
    let activeTab = "daily";
    let activeGallery = "all";
    let holidayMap = {};

    document.addEventListener("DOMContentLoaded", async function () {
      bindEvents();
      await loadInitialData();
    });

    function bindEvents() {
      document.querySelectorAll(".report-tab").forEach(function (btn) {
        btn.addEventListener("click", function () {
          document.querySelectorAll(".report-tab").forEach(function (item) {
            item.classList.remove("active");
          });

          btn.classList.add("active");
          activeTab = btn.dataset.tab;
          toggleFilterFields();
          renderDashboard();
        });
      });

      document.querySelectorAll(".gallery-chip").forEach(function (btn) {
        btn.addEventListener("click", function () {
          document.querySelectorAll(".gallery-chip").forEach(function (item) {
            item.classList.remove("active");
          });

          btn.classList.add("active");
          activeGallery = btn.dataset.gallery;
          renderGallery();
        });
      });

      document.getElementById("reportDate").addEventListener("change", function () {
        enforceOperationalDateSelection();
        renderDashboard();
      });
      document.getElementById("reportMonth").addEventListener("change", renderDashboard);
      document.getElementById("reportSppg").addEventListener("change", renderDashboard);
    }

    async function loadInitialData() {
      const errorBox = document.getElementById("errorBox");

      try {
        const [monitoringRes, sppgRes, holidaysRes] = await Promise.all([
          fetch("/api/public-monitoring", { cache: "no-store" }),
          fetch("/api/list-sppg", { cache: "no-store" }),
          fetch("/api/holidays", { cache: "no-store" })
        ]);

        const monitoringJson = await monitoringRes.json();
        const sppgJson = await sppgRes.json();
        const holidaysJson = await holidaysRes.json();

        if (!monitoringJson.success) {
          throw new Error(monitoringJson.message || "Gagal mengambil data monitoring.");
        }

        monitoringData = Array.isArray(monitoringJson.data) ? monitoringJson.data : [];
        allSppgList = sppgJson && sppgJson.success && Array.isArray(sppgJson.data)
          ? sppgJson.data.filter(Boolean)
          : [...new Set(monitoringData.map(item => item.namaSppg).filter(Boolean))];

        holidayMap = normalizeHolidayMap(holidaysJson && holidaysJson.success ? holidaysJson.data : []);

        populateSppgSelect();
        setDefaultFilters();
        toggleFilterFields();
        renderDashboard();

      } catch (error) {
        console.error(error);
        errorBox.style.display = "block";
        errorBox.textContent = error.message || "Gagal memuat data monitoring.";
      }
    }

    function populateSppgSelect() {
      const select = document.getElementById("reportSppg");
      select.innerHTML = '<option value="">Pilih SPPG</option>';

      allSppgList.forEach(function (sppg) {
        const option = document.createElement("option");
        option.value = sppg;
        option.textContent = sppg;
        select.appendChild(option);
      });

      if (allSppgList.length > 0) {
        select.value = allSppgList[0];
      }
    }

    function setDefaultFilters() {
      const latestDate = getLatestOperationalDateFromData() || getNearestPreviousOperationalDate(getTodayInputValue());
      document.getElementById("reportDate").value = latestDate;
      document.getElementById("reportMonth").value = latestDate.slice(0, 7);
    }

    function toggleFilterFields() {
      const fieldDate = document.getElementById("fieldDate");
      const fieldMonth = document.getElementById("fieldMonth");
      const fieldSppg = document.getElementById("fieldSppg");

      if (activeTab === "daily") {
        fieldDate.style.display = "block";
        fieldMonth.style.display = "none";
        fieldSppg.style.display = "none";
      } else if (activeTab === "monthly") {
        fieldDate.style.display = "none";
        fieldMonth.style.display = "block";
        fieldSppg.style.display = "none";
      } else {
        fieldDate.style.display = "none";
        fieldMonth.style.display = "block";
        fieldSppg.style.display = "block";
      }
    }

    function renderDashboard() {
      renderReportHeader();
      renderExecutive();
      renderSummary();
      renderStatusStrip();
      renderGallery();
      renderRecap();
      renderFooter();
    }

    function renderReportHeader() {
      const titleSub = document.getElementById("reportTitleSub");
      const periodLabel = document.getElementById("periodLabel");
      const periodValue = document.getElementById("periodValue");

      if (activeTab === "daily") {
        const selectedDate = document.getElementById("reportDate").value;
        titleSub.textContent = "Laporan Harian";
        periodLabel.textContent = "Tanggal";
        periodValue.textContent = isOperationalDate(selectedDate)
          ? formatTanggalShortCard(selectedDate)
          : formatTanggalShortCard(selectedDate) + " · Non-operasional";
      } else if (activeTab === "monthly") {
        titleSub.textContent = "Laporan Bulanan";
        periodLabel.textContent = "Bulan";
        periodValue.textContent = formatMonthLabel(document.getElementById("reportMonth").value);
      } else {
        titleSub.textContent = "Laporan Bulanan per SPPG";
        periodLabel.textContent = "SPPG";
        periodValue.textContent = document.getElementById("reportSppg").value || "-";
      }
    }

    function getFilteredRows() {
      const dateValue = document.getElementById("reportDate").value;
      const monthValue = document.getElementById("reportMonth").value;
      const sppgValue = document.getElementById("reportSppg").value;

      return monitoringData.filter(function (item) {
        const itemDate = normalizeDate(item.tanggal);
        const itemMonth = itemDate ? itemDate.slice(0, 7) : "";

        // Data pada Sabtu, Minggu, dan libur nasional tidak dihitung dalam laporan operasional.
        if (!isOperationalDate(itemDate)) {
          return false;
        }

        if (activeTab === "daily") {
          return itemDate === dateValue && isOperationalDate(dateValue);
        }

        if (activeTab === "monthly") {
          return itemMonth === monthValue;
        }

        return itemMonth === monthValue && item.namaSppg === sppgValue;
      });
    }

    function getScopeSppgList() {
      if (activeTab === "sppgMonthly") {
        const selected = document.getElementById("reportSppg").value;
        return selected ? [selected] : [];
      }

      return allSppgList.length > 0
        ? allSppgList
        : [...new Set(monitoringData.map(item => item.namaSppg).filter(Boolean))];
    }

    function getScopeDates() {
      if (activeTab === "daily") {
        const selectedDate = normalizeDate(document.getElementById("reportDate").value);
        return isOperationalDate(selectedDate) ? [selectedDate] : [];
      }

      // Rekap bulanan wajib hanya berisi hari operasional.
      // Sabtu, Minggu, dan tanggal libur nasional tidak dimasukkan sebagai kolom.
      return getOperationalDatesInMonth(document.getElementById("reportMonth").value);
    }

    function buildPresenceMap(rows) {
      const map = {};

      rows.forEach(function (item) {
        const sppg = String(item.namaSppg || "").trim();
        const date = normalizeDate(item.tanggal);

        if (!sppg || !date) return;

        const key = sppg + "||" + date;

        if (!map[key]) {
          map[key] = {
            count: 0,
            rows: []
          };
        }

        map[key].count += 1;
        map[key].rows.push(item);
      });

      return map;
    }

    function renderExecutive() {
      const rows = getFilteredRows();
      const scopeSppg = getScopeSppgList();
      const scopeDates = getScopeDates();
      const presenceMap = buildPresenceMap(rows);

      let checkedCells = 0;
      scopeSppg.forEach(function (sppg) {
        scopeDates.forEach(function (date) {
          const key = sppg + "||" + date;
          if (presenceMap[key]) checkedCells += 1;
        });
      });

      const totalSlots = scopeSppg.length * scopeDates.length;
      const compliance = totalSlots > 0 ? Math.round((checkedCells / totalSlots) * 100) : 0;

      const updatedSppgSet = new Set(rows.map(item => item.namaSppg).filter(Boolean));
      const notUpdated = Math.max(scopeSppg.length - updatedSppgSet.size, 0);

      const totalFotoMenu = rows.filter(item => item.linkFotoMenu).length;
      const totalFotoDistribusi = rows.filter(item => item.linkFotoDistribusi).length;

      const items = [
        { icon: "🏫", value: scopeSppg.length, label: "SPPG Aktif" },
        { icon: "📝", value: rows.length, label: "Total Monitoring" },
        { icon: "📅", value: scopeDates.length, label: activeTab === "daily" ? "Tanggal Monitoring" : "Hari Monitoring" },
        { icon: "✅", value: compliance + "%", label: "Kepatuhan Input" },
        { icon: "🍱", value: totalFotoMenu, label: "Total Foto Menu" },
        { icon: "🚚", value: totalFotoDistribusi, label: "Total Foto Distribusi" },
        { icon: "❌", value: notUpdated, label: "SPPG Belum Upload" }
      ];

      const executiveList = document.getElementById("executiveList");
      executiveList.innerHTML = items.map(function (item) {
        return `
          <div class="exec-item">
            <div class="exec-icon">${item.icon}</div>
            <div>
              <div class="exec-value">${escapeHtml(item.value)}</div>
              <div class="exec-label">${escapeHtml(item.label)}</div>
            </div>
          </div>
        `;
      }).join("");
    }

    function renderSummary() {
      const rows = getFilteredRows();
      const scopeSppg = getScopeSppgList();
      const scopeDates = getScopeDates();
      const presenceMap = buildPresenceMap(rows);

      let checkedCells = 0;
      scopeSppg.forEach(function (sppg) {
        scopeDates.forEach(function (date) {
          const key = sppg + "||" + date;
          if (presenceMap[key]) checkedCells += 1;
        });
      });

      const totalSlots = scopeSppg.length * scopeDates.length;
      const percent = totalSlots > 0 ? Math.round((checkedCells / totalSlots) * 100) : 0;

      const updatedSppg = new Set(rows.map(item => item.namaSppg).filter(Boolean)).size;
      const avgPerDay = scopeDates.length > 0 ? (rows.length / scopeDates.length).toFixed(2) : "0.00";

      const cards = [
        {
          label: "Total Laporan",
          value: rows.length,
          desc: "Jumlah seluruh laporan pada periode yang dipilih."
        },
        {
          label: "SPPG Melapor",
          value: updatedSppg,
          desc: "Jumlah SPPG yang telah mengirim data."
        },
        {
          label: "Rata-rata Monitoring / Hari",
          value: avgPerDay,
          desc: "Rerata jumlah laporan per hari pada periode ini."
        },
        {
          label: "Persentase Monitoring",
          value: percent + "%",
          desc: "Perbandingan data yang masuk terhadap seluruh slot monitoring."
        }
      ];

      document.getElementById("summaryGrid").innerHTML = cards.map(function (card) {
        return `
          <div class="summary-card">
            <div class="summary-label">${escapeHtml(card.label)}</div>
            <div class="summary-value">${escapeHtml(card.value)}</div>
            <div class="summary-desc">${escapeHtml(card.desc)}</div>
          </div>
        `;
      }).join("");
    }

    function renderStatusStrip() {
      const rows = getFilteredRows();
      const scopeSppg = getScopeSppgList();
      const scopeDates = getScopeDates();
      const presenceMap = buildPresenceMap(rows);

      let checkedCells = 0;
      scopeSppg.forEach(function (sppg) {
        scopeDates.forEach(function (date) {
          const key = sppg + "||" + date;
          if (presenceMap[key]) checkedCells += 1;
        });
      });

      const totalSlots = scopeSppg.length * scopeDates.length;
      const compliance = totalSlots > 0 ? Math.round((checkedCells / totalSlots) * 100) : 0;
      const notUploadedCells = Math.max(totalSlots - checkedCells, 0);
      const availableDocs = rows.filter(item => item.linkFotoMenu || item.linkFotoDistribusi).length;

      const statuses = [
        {
          cls: compliance >= 85 ? "good" : compliance >= 60 ? "warn" : "danger",
          small: "Status Kepatuhan",
          big: compliance >= 85 ? "Sangat Baik" : compliance >= 60 ? "Cukup" : "Perlu Perhatian"
        },
        {
          cls: "neutral",
          small: "Slot Terisi",
          big: checkedCells + " / " + totalSlots
        },
        {
          cls: notUploadedCells > 0 ? "danger" : "good",
          small: "Belum Upload",
          big: notUploadedCells
        },
        {
          cls: availableDocs > 0 ? "good" : "neutral",
          small: "Dokumentasi Tersedia",
          big: availableDocs
        }
      ];

      document.getElementById("statusStrip").innerHTML = statuses.map(function (item) {
        return `
          <div class="status-box ${item.cls}">
            <div class="small">${escapeHtml(item.small)}</div>
            <div class="big">${escapeHtml(item.big)}</div>
          </div>
        `;
      }).join("");
    }

    function renderGallery() {
      const rows = getFilteredRows();
      const gallery = document.getElementById("galleryGrid");

      let docs = rows.slice();

      if (activeGallery === "menu") {
        docs = docs.filter(item => item.linkFotoMenu);
      }

      if (activeGallery === "distribution") {
        docs = docs.filter(item => item.linkFotoDistribusi);
      }

      docs = docs.slice(0, 20);

      if (docs.length === 0) {
        gallery.innerHTML = '<div class="empty-state" style="grid-column:1 / -1;">Tidak ada dokumentasi pada periode ini.</div>';
        return;
      }

      gallery.innerHTML = docs.map(function (item) {
        return `
          <div class="doc-card">
            <div class="doc-head">
              <div class="doc-sppg">${escapeHtml(item.namaSppg || "-")}</div>
              <div class="doc-date">${escapeHtml(formatTanggal(item.tanggal))}</div>
            </div>

            <div class="doc-images">
              ${renderPhotoBox("Foto Menu", item.linkFotoMenu)}
              ${renderPhotoBox("Foto Distribusi", item.linkFotoDistribusi)}
            </div>
          </div>
        `;
      }).join("");
    }

    function renderPhotoBox(label, url) {
  if (!url) {
    return `
      <div class="doc-photo-box">
        <div class="doc-photo-label">${escapeHtml(label)}</div>
        <div class="doc-empty">Belum ada foto</div>
      </div>
    `;
  }

  const imgUrl = driveImageUrl(url);

  return `
    <div class="doc-photo-box">
      <div class="doc-photo-label">${escapeHtml(label)}</div>

      <a href="${escapeAttr(url)}" target="_blank" class="doc-image-link">
        <img
          src="${escapeAttr(imgUrl)}"
          alt="${escapeAttr(label)}"
          loading="lazy"
          onerror="this.style.display='none'; this.parentElement.nextElementSibling.style.display='flex';"
        />
      </a>

      <a class="doc-fallback" href="${escapeAttr(url)}" target="_blank">
        Buka Foto
      </a>
    </div>
  `;
}
    function renderRecap() {
      const rows = getFilteredRows();
      const scopeSppg = getScopeSppgList();
      const scopeDates = getScopeDates();
      const presenceMap = buildPresenceMap(rows);

      const recapHead = document.getElementById("recapHead");
      const recapBody = document.getElementById("recapBody");

      if (scopeSppg.length === 0 || scopeDates.length === 0) {
        recapHead.innerHTML = "";
        const selectedDate = document.getElementById("reportDate").value;
        const selectedMonth = document.getElementById("reportMonth").value;
        let emptyMessage = "Tidak ada data rekapitulasi.";

        if (activeTab === "daily" && selectedDate && !isOperationalDate(selectedDate)) {
          const reason = getNonOperationalReason(selectedDate);
          emptyMessage = "Tanggal " + formatTanggal(selectedDate) + " tidak dihitung karena " + reason + ".";
        } else if (activeTab !== "daily" && selectedMonth) {
          emptyMessage = "Tidak ada tanggal operasional pada periode ini.";
        }

        recapBody.innerHTML = '<tr><td class="empty-state">' + escapeHtml(emptyMessage) + '</td></tr>';
        return;
      }

      recapHead.innerHTML = `
        <tr>
          <th class="sticky-left">Nama SPPG</th>
          ${scopeDates.map(function (date) {
            return `<th class="date-col">${escapeHtml(formatDateCell(date))}</th>`;
          }).join("")}
          <th>Total Hari Input</th>
          <th>% Kepatuhan</th>
          <th>Status</th>
        </tr>
      `;

      recapBody.innerHTML = scopeSppg.map(function (sppg) {
        let totalInputDays = 0;
        const dateCells = scopeDates.map(function (date) {
          const key = sppg + "||" + date;
          const found = presenceMap[key];

          if (found) {
            totalInputDays += 1;
            return `
              <td class="date-col" title="${escapeAttr(sppg + ' - ' + formatTanggal(date) + ' : ' + found.count + ' laporan')}">
                <span class="status-icon ok">
                  ✓
                  ${found.count > 1 ? `<span class="status-count">${found.count}</span>` : ""}
                </span>
              </td>
            `;
          }

          return `
            <td class="date-col" title="${escapeAttr(sppg + ' - ' + formatTanggal(date) + ' : belum upload')}">
              <span class="status-icon no">✕</span>
            </td>
          `;
        }).join("");

        const percent = scopeDates.length > 0 ? Math.round((totalInputDays / scopeDates.length) * 100) : 0;
        const statusClass = percent >= 85 ? "good" : percent >= 60 ? "warn" : "bad";
        const statusText = percent >= 85 ? "Sangat Baik" : percent >= 60 ? "Cukup" : "Perlu Perhatian";

        return `
          <tr>
            <td class="sticky-left"><strong>${escapeHtml(sppg)}</strong></td>
            ${dateCells}
            <td>${totalInputDays}</td>
            <td><span class="percent-pill ${statusClass}">${percent}%</span></td>
            <td><span class="percent-pill ${statusClass}">${statusText}</span></td>
          </tr>
        `;
      }).join("");
    }

    async function exportReportPDF() {
      const element = document.getElementById("pdfReportArea");
      const title = buildExportTitle();
      const filename = title + ".pdf";

      document.body.classList.add("pdf-mode");
      await waitForImages(element);

      const opt = {
        margin: 6,
        filename: filename,
        image: { type: "jpeg", quality: 0.98 },
        html2canvas: {
          scale: 2,
          useCORS: true,
          allowTaint: false,
          imageTimeout: 15000,
          scrollY: 0
        },
        jsPDF: {
          unit: "mm",
          format: "a4",
          orientation: "landscape"
        },
        pagebreak: {
          mode: ["avoid-all", "css", "legacy"]
        }
      };

      html2pdf()
        .set(opt)
        .from(element)
        .save()
        .then(function () {
          document.body.classList.remove("pdf-mode");
        })
        .catch(function (error) {
          console.error(error);
          document.body.classList.remove("pdf-mode");
          alert("Gagal membuat PDF. Silakan coba lagi.");
        });
    }

    function buildExportTitle() {
      const today = new Date().toISOString().slice(0, 10);

      if (activeTab === "daily") {
        return "laporan-harian-mbg-" + document.getElementById("reportDate").value + "-" + today;
      }

      if (activeTab === "monthly") {
        return "laporan-bulanan-mbg-" + document.getElementById("reportMonth").value + "-" + today;
      }

      const sppg = (document.getElementById("reportSppg").value || "sppg")
        .toLowerCase()
        .replaceAll(" ", "-");
      return "laporan-bulanan-sppg-" + sppg + "-" + document.getElementById("reportMonth").value + "-" + today;
    }

    function enforceOperationalDateSelection() {
      const input = document.getElementById("reportDate");
      if (!input || !input.value) return;

      const selectedDate = normalizeDate(input.value);
      if (isOperationalDate(selectedDate)) {
        input.value = selectedDate;
        return;
      }

      const replacementDate = getNearestPreviousOperationalDate(selectedDate);
      const reason = getNonOperationalReason(selectedDate);

      input.value = replacementDate;

      const errorBox = document.getElementById("errorBox");
      if (errorBox) {
        errorBox.style.display = "block";
        errorBox.textContent = "Tanggal " + formatTanggal(selectedDate) + " tidak dihitung karena " + reason + ". Sistem otomatis memakai tanggal operasional terdekat sebelumnya: " + formatTanggal(replacementDate) + ".";

        window.clearTimeout(window.__operationalDateNoticeTimer);
        window.__operationalDateNoticeTimer = window.setTimeout(function () {
          errorBox.style.display = "none";
        }, 4500);
      }
    }

    function renderFooter() {
      document.getElementById("footerGenerated").textContent =
        "Dicetak " + new Date().toLocaleString("id-ID");
    }

    function getLatestOperationalDateFromData() {
      const dates = monitoringData
        .map(item => normalizeDate(item.tanggal))
        .filter(function (date) {
          return date && isOperationalDate(date);
        })
        .sort(function (a, b) {
          return new Date(b) - new Date(a);
        });

      return dates[0] || "";
    }

    function getTodayInputValue() {
      const date = new Date();
      const y = date.getFullYear();
      const m = String(date.getMonth() + 1).padStart(2, "0");
      const d = String(date.getDate()).padStart(2, "0");
      return `${y}-${m}-${d}`;
    }

    function normalizeHolidayMap(list) {
      const map = {};

      if (!Array.isArray(list)) {
        return map;
      }

      list.forEach(function (item) {
        if (!item) return;

        const date = normalizeDate(item.tanggal || item.date || item[0]);
        const name = String(item.keterangan || item.name || item[1] || "Libur nasional").trim();

        if (date) {
          map[date] = name || "Libur nasional";
        }
      });

      return map;
    }

    function isWeekend(dateValue) {
      const date = normalizeDate(dateValue);
      if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return false;

      const parts = date.split("-").map(Number);
      const year = parts[0];
      const month = parts[1];
      const day = parts[2];

      // Pakai constructor lokal agar tidak kena pergeseran timezone UTC.
      const localDate = new Date(year, month - 1, day);
      const weekDay = localDate.getDay();

      // 0 = Minggu, 6 = Sabtu
      return weekDay === 0 || weekDay === 6;
    }

    function isHoliday(dateValue) {
      const date = normalizeDate(dateValue);
      return Boolean(date && holidayMap[date]);
    }

    function isOperationalDate(dateValue) {
      const date = normalizeDate(dateValue);
      if (!date) return false;

      return !isWeekend(date) && !isHoliday(date);
    }

    function getNonOperationalReason(dateValue) {
      const date = normalizeDate(dateValue);

      if (isWeekend(date)) {
        const parts = date.split("-").map(Number);
        const day = new Date(parts[0], parts[1] - 1, parts[2]).getDay();
        return day === 6 ? "hari Sabtu" : "hari Minggu";
      }

      if (isHoliday(date)) {
        return "libur nasional" + (holidayMap[date] ? " (" + holidayMap[date] + ")" : "");
      }

      return "hari non-operasional";
    }

    function getNearestPreviousOperationalDate(startDate) {
      let date = normalizeDate(startDate) || getTodayInputValue();

      for (let i = 0; i < 370; i++) {
        if (isOperationalDate(date)) {
          return date;
        }

        const parts = date.split("-").map(Number);
        const d = new Date(parts[0], parts[1] - 1, parts[2]);
        d.setDate(d.getDate() - 1);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, "0");
        const day = String(d.getDate()).padStart(2, "0");
        date = `${y}-${m}-${day}`;
      }

      return startDate;
    }

    function getOperationalDatesInMonth(monthValue) {
      return getDatesInMonth(monthValue).filter(function (date) {
        return isOperationalDate(date);
      });
    }

    function getDatesInMonth(monthValue) {
      if (!monthValue) return [];

      const [yearStr, monthStr] = monthValue.split("-");
      const year = Number(yearStr);
      const month = Number(monthStr);

      if (!year || !month) return [];

      const lastDate = new Date(year, month, 0).getDate();
      const dates = [];

      for (let day = 1; day <= lastDate; day++) {
        dates.push(`${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`);
      }

      return dates;
    }

    function normalizeDate(value) {
      if (!value) return "";

      const raw = String(value).trim();

      if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
        return raw;
      }

      const ddmmyyyy = raw.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
      if (ddmmyyyy) {
        const d = String(ddmmyyyy[1]).padStart(2, "0");
        const m = String(ddmmyyyy[2]).padStart(2, "0");
        const y = ddmmyyyy[3];
        return `${y}-${m}-${d}`;
      }

      const date = new Date(raw);
      if (isNaN(date.getTime())) return raw;

      const y = date.getFullYear();
      const m = String(date.getMonth() + 1).padStart(2, "0");
      const d = String(date.getDate()).padStart(2, "0");

      return `${y}-${m}-${d}`;
    }

    function formatTanggal(value) {
      if (!value) return "-";

      const date = new Date(normalizeDate(value) + "T00:00:00");
      if (isNaN(date.getTime())) return value;

      return date.toLocaleDateString("id-ID", {
        day: "2-digit",
        month: "long",
        year: "numeric"
      });
    }

    function formatTanggalShortCard(value) {
      if (!value) return "-";

      const date = new Date(normalizeDate(value) + "T00:00:00");
      if (isNaN(date.getTime())) return value;

      return date.toLocaleDateString("id-ID", {
        day: "2-digit",
        month: "short",
        year: "numeric"
      });
    }

    function formatMonthLabel(value) {
      if (!value) return "-";

      const date = new Date(value + "-01T00:00:00");
      if (isNaN(date.getTime())) return value;

      return date.toLocaleDateString("id-ID", {
        month: "long",
        year: "numeric"
      }).toUpperCase();
    }

    function formatDateCell(value) {
      if (!value) return "-";
      const d = Number(value.slice(-2));
      return d;
    }

    function driveImageUrl(url) {
  const id = extractDriveFileId(url);

  if (!id) {
    return url;
  }

  return "/api/drive-image?id=" + encodeURIComponent(id);
}

function extractDriveFileId(url) {
  const value = String(url || "");

  let match = value.match(/\/d\/([a-zA-Z0-9_-]+)/);
  if (match && match[1]) return match[1];

  match = value.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (match && match[1]) return match[1];

  return "";
}
    function waitForImages(container) {
      const images = Array.from(container.querySelectorAll("img"));

      const promises = images.map(function (img) {
        return new Promise(function (resolve) {
          if (img.complete) {
            resolve();
            return;
          }

          img.onload = function () { resolve(); };
          img.onerror = function () { resolve(); };
        });
      });

      return Promise.all(promises);
    }

    function escapeHtml(value) {
      return String(value || "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
    }

    function escapeAttr(value) {
      return String(value || "")
        .replaceAll("&", "&amp;")
        .replaceAll('"', "&quot;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;");
    }
  