/****************************************************
 PATCH APPS SCRIPT: Hari Libur Nasional untuk Monitoring MBG

 Cara pakai:
 1. Tambahkan konstanta ini di bagian atas script:
    const SHEET_HARI_LIBUR = "Hari Libur Nasional";

 2. Tambahkan router ini di dalam doPost(e), sebelum return action tidak dikenal:
    if (data.action === "getHariLibur") {
      return jsonResponse(getHariLibur_());
    }

 3. Tambahkan fungsi getHariLibur_() di bawah fungsi lain.

 4. Buat sheet baru bernama "Hari Libur Nasional" dengan header:
    Tanggal | Keterangan | Status

    Contoh isi:
    2026-01-01 | Tahun Baru Masehi | Aktif
    2026-03-20 | Hari Raya Nyepi | Aktif

    Status boleh dikosongkan. Jika ingin menonaktifkan satu tanggal,
    isi Status dengan: Nonaktif / Tidak Aktif / false / 0
****************************************************/

const SHEET_HARI_LIBUR = "Hari Libur Nasional";

function getHariLibur_() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName(SHEET_HARI_LIBUR);

  if (!sheet) {
    return {
      success: true,
      message: 'Sheet "Hari Libur Nasional" belum dibuat. Sistem hanya mengecualikan Sabtu dan Minggu.',
      data: []
    };
  }

  const lastRow = sheet.getLastRow();

  if (lastRow < 2) {
    return {
      success: true,
      message: "Data hari libur nasional masih kosong.",
      data: []
    };
  }

  const values = sheet.getRange(2, 1, lastRow - 1, 3).getValues();
  const seen = {};
  const data = [];

  values.forEach(function(row) {
    const tanggalRaw = row[0];
    const keterangan = String(row[1] || "Libur nasional").trim();
    const status = String(row[2] || "Aktif").trim().toLowerCase();

    if (
      status === "nonaktif" ||
      status === "tidak aktif" ||
      status === "false" ||
      status === "0"
    ) {
      return;
    }

    let tanggal = "";

    if (tanggalRaw instanceof Date) {
      tanggal = Utilities.formatDate(tanggalRaw, TIMEZONE, "yyyy-MM-dd");
    } else {
      tanggal = normalizeDateText_(tanggalRaw);
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(tanggal)) {
      return;
    }

    if (seen[tanggal]) {
      return;
    }

    seen[tanggal] = true;
    data.push({
      tanggal: tanggal,
      keterangan: keterangan || "Libur nasional"
    });
  });

  data.sort(function(a, b) {
    return a.tanggal.localeCompare(b.tanggal);
  });

  return {
    success: true,
    message: "Data hari libur nasional berhasil diambil.",
    data: data
  };
}
