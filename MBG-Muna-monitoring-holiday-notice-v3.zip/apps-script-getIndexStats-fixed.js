// Ganti hanya fungsi getIndexStats_() di Apps Script dengan versi ini.
// Setelah diganti: Save > Deploy > Manage deployments > Edit > New version > Deploy.

function getIndexStats_() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);

  let totalSppgAktif = 0;
  let totalSekolahPenerima = 128;
  let totalSppgMelaporHariIni = 0;
  let totalAduanDitindaklanjuti = 0;

  // Hitung SPPG aktif dari sheet users jika tersedia.
  const userSheet = ss.getSheetByName(SHEET_USERS);

  if (userSheet && userSheet.getLastRow() >= 2) {
    const users = userSheet
      .getRange(2, 1, userSheet.getLastRow() - 1, Math.max(userSheet.getLastColumn(), 4))
      .getValues();

    const sppgAktifSet = new Set();

    users.forEach(function(row) {
      const sppg = String(row[2] || "").trim();
      const status = String(row[3] || "").trim().toLowerCase();

      if (sppg && sppg.toLowerCase() !== "admin" && status === "aktif") {
        sppgAktifSet.add(sppg.toLowerCase());
      }
    });

    totalSppgAktif = sppgAktifSet.size;
  }

  // Fallback kalau sheet users belum lengkap.
  if (!totalSppgAktif) {
    totalSppgAktif = 27;
  }

  const todayText = Utilities.formatDate(new Date(), TIMEZONE, "yyyy-MM-dd");

  // Hitung SPPG unik yang sudah melapor hari ini.
  const dataSheet = ss.getSheetByName(SHEET_DATA);

  if (dataSheet && dataSheet.getLastRow() >= 2) {
    const values = dataSheet
      .getRange(2, 1, dataSheet.getLastRow() - 1, 8)
      .getValues();

    const sppgMelaporSet = new Set();

    values.forEach(function(row) {
      const namaSppg = String(row[0] || "").trim();
      const tanggalRaw = row[1];

      let tanggalText = "";

      if (tanggalRaw instanceof Date) {
        tanggalText = Utilities.formatDate(tanggalRaw, TIMEZONE, "yyyy-MM-dd");
      } else {
        tanggalText = normalizeDateText_(tanggalRaw);
      }

      if (namaSppg && tanggalText === todayText) {
        sppgMelaporSet.add(namaSppg.toLowerCase());
      }
    });

    totalSppgMelaporHariIni = sppgMelaporSet.size;
  }

  // Hitung aduan yang sudah ditindaklanjuti berdasarkan kolom Status.
  // Sheet Layanan aduan harus punya kolom ke-7 bernama Status.
  const aduanSheet = getAduanSheet_(ss);

  if (aduanSheet && aduanSheet.getLastRow() >= 2) {
    const lastRow = aduanSheet.getLastRow();
    const lastCol = Math.max(aduanSheet.getLastColumn(), 7);

    const aduanValues = aduanSheet
      .getRange(2, 1, lastRow - 1, lastCol)
      .getValues();

    totalAduanDitindaklanjuti = aduanValues.filter(function(row) {
      const status = String(row[6] || "").trim().toLowerCase();

      return (
        status === "ditindaklanjuti" ||
        status === "selesai" ||
        status === "selesai ditindaklanjuti"
      );
    }).length;
  }

  return {
    success: true,
    message: "Statistik index berhasil diambil.",
    data: {
      totalSppgAktif: totalSppgAktif,
      totalSekolahPenerima: totalSekolahPenerima,
      totalSppgMelaporHariIni: totalSppgMelaporHariIni,
      totalAduan: totalAduanDitindaklanjuti,
      updatedAt: Utilities.formatDate(new Date(), TIMEZONE, "yyyy-MM-dd HH:mm:ss")
    }
  };
}
